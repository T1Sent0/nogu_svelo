import '../../components/head/fullpage/jquery.fullPage'
import Parallax from 'parallax-js'

$(document).ready(function () {

    $('.stena').addClass('animated bounceInUp');

    $('.text-panki').addClass('animated zoomInLeft');

   $('.logo').addClass('animate rotateIn');

   $('.logo').addClass('animate bounceIn').removeClass('rotateIn');

    setTimeout(function () {

        $('#fullpage').fullpage({
            // anchors:['firstSection', 'secondSection', 'thirdSection', 'fourthSection', 'fifthSection', 'sixSection'],
            navigation: false,
            scrollingSpeed: 700,
            autoScrolling: true,
            // fitToSection: true,
            fitToSectionDelay: 1000,
            scrollBar: false,
            responsiveWidth: 900,
            // continuousVertical: true,
            loopTop: false,
            loopBottom: true,
            controlArrows: false,

            onLeave: function(index, nextIndex, direction) {
                // if (direction === 'up' && nextIndex <= 3) {
                //     console.log("1234");
                //     return false;
                // } else {
                //     return true;
                // }
            },

            afterLoad: function(anchorLink, index) {
                if(index === 3) {
                    console.log(index);
                    $('.screen-effect-for-img').addClass('animated fadeInRight');
                    $('.screen-effect-for-text').addClass('animated fadeInUp');
                }

                if(index === 4) {
                    console.log(index);
                    $('.img-slide').addClass('animated fadeInRight');
                    $('.text-silde').addClass('animated fadeInUp');
                    $('.no-melancholy').addClass('animated swing');
                    setTimeout(function () {
                        $('.buy-ticket').css({display: 'block'});
                    }, 3000);
                }

                if (index === 4) {
                    console.log("4444");
                    $.fn.fullpage.moveTo(0, 0);

                    return true
                }
            }

        });

        setTimeout(function () {
            $('.stena').addClass('slideOutDown').removeClass('bounceInUp');
            $('.stena').addClass('animated bounceInDown');

            $('.stena').remove();
            $('.section').css({display: 'table'});
            $('.slide-one').addClass('active');
            $('#fullpage').css({background: 'white'});
            $('.steklo').css({opacity: '1', transition: "opacity .5s"});
            setTimeout(function () {
                $('.title-slide').css({opacity: '1', transition: "opacity .5s"});
            }, 1000);

            setTimeout(function () {
                $('.circle').css({opacity: '1', transition: "opacity 1s"});
            }, 1500);

            setTimeout(function () {
                $('.block-buy-ticket, .block-bottom').css({opacity: '1', transition: "opacity 0s"});

                let scene = document.getElementById('scene');
                let parallaxInstance = new Parallax(scene, {
                    pointerEvents:true
                });
                parallaxInstance.enable();
            }, 2100);
        }, 2000);


        setTimeout(function () {
            $('.slide-one > .fp-tableCell').attr('id', 'scene');
        },1000)
    },2700);


    $(document).on('click', '.buy-ticket', function () {
        $.fn.fullpage.moveTo(2,0);
    })

});