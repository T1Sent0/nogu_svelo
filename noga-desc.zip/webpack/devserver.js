module.exports = function () {
    return {
        devServer: {
            port: 9000,
            // hot: true,
            // inline: true,
            open: true,
            noInfo: true,
        }
    }
};